export { default } from './TermsOfUse';
