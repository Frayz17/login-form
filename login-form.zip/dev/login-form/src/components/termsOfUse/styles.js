import { makeStyles } from '@material-ui/core/styles';


const useStyles = makeStyles(() => ({
  caption: {
    fontSize: 11,
    color: '#43425d',
  },
}));

export default useStyles;
